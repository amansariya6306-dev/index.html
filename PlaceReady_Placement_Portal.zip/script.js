const menuBtn = document.getElementById('menuBtn');
const navLinks = document.getElementById('navLinks');
menuBtn.addEventListener('click', () => navLinks.classList.toggle('open'));
navLinks.querySelectorAll('a').forEach(link => link.addEventListener('click', () => navLinks.classList.remove('open')));

document.getElementById('year').textContent = new Date().getFullYear();

const toast = document.getElementById('toast');
let toastTimer;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
}

document.querySelectorAll('[data-track]').forEach(button => {
  button.addEventListener('click', () => {
    const track = button.dataset.track;
    const tips = {
      'Aptitude & Reasoning': 'Start with percentages, ratios, averages, number series, and logical reasoning.',
      'Coding & DSA': 'Start with variables, loops, arrays, strings, sorting, and simple problem-solving.',
      'CS Fundamentals': 'Revise DBMS, SQL, operating systems, computer networks, and OOP concepts.',
      'Resume & Interviews': 'Prepare a one-page resume, explain your projects, and practise common HR questions.'
    };
    showToast(tips[track] || 'Choose one small topic and practise it today.');
  });
});

const questionBank = [
  {q:'If 5 pens cost ₹60, what is the cost of 8 pens at the same rate?', options:['₹84','₹96','₹100','₹108'], answer:1, explain:'One pen costs ₹60 ÷ 5 = ₹12. So 8 pens cost 8 × ₹12 = ₹96.'},
  {q:'What is 25% of 240?', options:['40','50','60','80'], answer:2, explain:'25% is one-fourth. 240 ÷ 4 = 60.'},
  {q:'A number is multiplied by 3 and then 4 is added. The result is 19. What is the number?', options:['3','4','5','6'], answer:2, explain:'Let the number be x. 3x + 4 = 19, so 3x = 15 and x = 5.'},
  {q:'Find the next number: 2, 4, 8, 16, __', options:['18','24','30','32'], answer:3, explain:'Each number is multiplied by 2. The next number is 16 × 2 = 32.'}
];
let questionIndex = 0;
let answered = false;
const questionTitle = document.querySelector('.quiz-card h3');
const optionButtons = [...document.querySelectorAll('.option')];
const feedback = document.getElementById('quizFeedback');
const nextButton = document.getElementById('nextQuestion');

function renderQuestion() {
  const item = questionBank[questionIndex];
  questionTitle.textContent = item.q;
  optionButtons.forEach((button, i) => {
    button.className = 'option';
    button.innerHTML = String.fromCharCode(65 + i) + ' <span>' + item.options[i] + '</span>';
    button.disabled = false;
  });
  feedback.textContent = 'Choose an option to check your answer.';
  feedback.className = 'feedback';
  nextButton.textContent = 'Try another question ↗';
  answered = false;
}
optionButtons.forEach((button, i) => {
  button.addEventListener('click', () => {
    if (answered) return;
    answered = true;
    const item = questionBank[questionIndex];
    optionButtons.forEach((b, j) => {
      b.disabled = true;
      if (j === item.answer) b.classList.add('correct');
    });
    if (i === item.answer) {
      feedback.textContent = 'Correct! ' + item.explain;
      feedback.className = 'feedback success';
    } else {
      button.classList.add('wrong');
      feedback.textContent = 'Not quite. ' + item.explain;
      feedback.className = 'feedback error';
    }
    nextButton.textContent = 'Next question →';
  });
});
nextButton.addEventListener('click', () => {
  if (!answered) {
    showToast('Choose an answer first to practise effectively.');
    return;
  }
  questionIndex = (questionIndex + 1) % questionBank.length;
  renderQuestion();
});

document.querySelectorAll('[data-check]').forEach(input => {
  input.addEventListener('change', () => {
    const completed = document.querySelectorAll('[data-check]:checked').length;
    const total = document.querySelectorAll('[data-check]').length;
    showToast(`${completed} of ${total} preparation tasks completed.`);
  });
});
